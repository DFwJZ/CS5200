module.exports = uri =
  "mongodb+srv://dbAdmin:mtGlJGumTlw3psIa@cluster0.xzu4lx9.mongodb.net/?retryWrites=true&w=majority";
